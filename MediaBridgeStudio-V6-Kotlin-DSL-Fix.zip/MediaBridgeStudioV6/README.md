# MediaBridge Studio V6

Android Studio source project for a ManyCam-inspired mobile studio prototype.

## GitHub repository links

Prepared for repository `MediaBridgeStudio` under GitHub account `ruwancbk`. These links become active after the repository is created and the project files are uploaded.

- GitHub profile: https://github.com/ruwancbk
- Repository: https://github.com/ruwancbk/MediaBridgeStudio
- Source code: https://github.com/ruwancbk/MediaBridgeStudio/tree/main
- GitHub Actions: https://github.com/ruwancbk/MediaBridgeStudio/actions
- Workflow file: https://github.com/ruwancbk/MediaBridgeStudio/blob/main/.github/workflows/android-build.yml
- Workflow runs: https://github.com/ruwancbk/MediaBridgeStudio/actions/workflows/android-build.yml
- Releases: https://github.com/ruwancbk/MediaBridgeStudio/releases
- Issues: https://github.com/ruwancbk/MediaBridgeStudio/issues

## Included prototype features

- CameraX camera preview and local MP4 camera recording with optional microphone audio.
- Import multiple photos and videos; persist playlist URI list/current index.
- Media3 local photo preview and video playback with playlist controls.
- Basic text and logo preview overlays.
- Source Manager for camera and imported media.
- WebView browser with Android document picker for standard HTML file uploads.
- Separate RootEncoder RTMP/RTMPS broadcast screen with camera/microphone streaming path.

## Current limitations

- RTMP broadcasts the separate camera/microphone path; it does not yet broadcast the composed Studio preview or imported media layers.
- Simultaneous multi-source compositing, chroma key, true multi-track audio mixing, scene transitions and overlay burn-in are not implemented yet.
- This is not a system-wide virtual camera.
- Source code only; no APK is included. The project has not yet been verified by a successful Android build or physical-device test.

## Build locally

Requirements: Android Studio, JDK 17, Android SDK Platform 35 and internet access.

1. Open this `MediaBridgeStudioV6` folder in Android Studio.
2. Allow Gradle sync and dependency downloads.
3. Select **Build > Build Bundle(s) / APK(s) > Build APK(s)**.

The project currently does not include Gradle Wrapper files. GitHub Actions installs Gradle 8.9 directly and runs `gradle :app:assembleDebug`.

## GitHub Actions: automatic APK build

Workflow path: `.github/workflows/android-build.yml`

It runs on:
- Pushes to `main` or `master`.
- Pull requests.
- Manual start from the Actions tab using **Run workflow**.

After a successful build:
1. Open the repository's **Actions** tab.
2. Open the latest **Android Build** run.
3. Scroll to **Artifacts**.
4. Download `MediaBridgeStudio-debug-apk`.
5. Extract the downloaded artifact ZIP to get the debug APK.

The APK artifact is retained for 30 days. It only exists after a successful workflow run.

## Upload to GitHub

Create a repository named `MediaBridgeStudio` under `ruwancbk`. Do not initialize it with a README, license or `.gitignore` because this project already includes a README.

Upload the **contents** of this folder (not the outer ZIP file and not an extra enclosing folder) to the repository root. Include `.github/workflows/android-build.yml`, then commit to `main`.

## RTMP security

Keep your streaming key private. Never commit real stream keys, passwords or service credentials.


## Kotlin compiler compatibility adjustment

This source package uses Kotlin Gradle Plugin 1.9.24 instead of 2.0.21.
The previous GitHub build log showed a Kotlin FIR compiler internal exception
(`IllegalArgumentException: source must not be null`) during `compileDebugKotlin`.
Using the stable 1.9.24 compiler frontend is a compatibility workaround to test
whether that compiler-internal failure is avoided. This change does not prove
the Android project will compile; any subsequent source/API errors must be fixed
from the next build log.
