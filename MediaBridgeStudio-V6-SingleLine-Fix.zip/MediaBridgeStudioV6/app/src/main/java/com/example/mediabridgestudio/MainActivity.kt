package com.example.mediabridgestudio

import android.Manifest
import android.content.Context
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Bundle
import android.view.Gravity
import android.view.ViewGroup
import android.webkit.ValueCallback
import android.webkit.WebChromeClient
import android.webkit.WebResourceRequest
import android.webkit.WebView
import android.webkit.WebViewClient
import android.widget.*
import androidx.activity.ComponentActivity
import androidx.activity.result.contract.ActivityResultContracts
import androidx.camera.core.CameraSelector
import androidx.camera.core.Preview
import androidx.camera.lifecycle.ProcessCameraProvider
import androidx.camera.video.*
import androidx.camera.view.PreviewView
import androidx.core.content.ContextCompat
import androidx.media3.common.MediaItem
import androidx.media3.exoplayer.ExoPlayer
import androidx.media3.ui.PlayerView
import java.io.File
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

/**
 * MediaBridge Studio V4.
 *
 * Implemented:
 * - CameraX preview and camera video recording (audio if permission granted).
 * - Local media import, playback and persisted URI playlist.
 * - Basic text and logo preview overlays.
 * - WebView file upload using Android document picker.
 * - RTMP settings storage (configuration only; no live RTMP transport yet).
 *
 * Not a system-wide virtual camera and not a complete broadcast compositor.
 */
class MainActivity : ComponentActivity() {
    private lateinit var stage: FrameLayout
    private lateinit var status: TextView
    private lateinit var prefs: android.content.SharedPreferences
    private lateinit var address: EditText

    private var cameraProvider: ProcessCameraProvider? = null
    private var videoCapture: VideoCapture<Recorder>? = null
    private var activeRecording: Recording? = null
    private var player: ExoPlayer? = null
    private var browser: WebView? = null
    private var pendingWebCallback: ValueCallback<Array<Uri>>? = null

    private val playlist = mutableListOf<Uri>()
    private var currentIndex = -1
    private var repeatOne = false
    private var shuffleNext = false
    private var currentPreview: FrameLayout? = null
    private var textOverlay: TextView? = null
    private var logoOverlay: ImageView? = null
    private var logoUri: Uri? = null

    private val mediaPicker = registerForActivityResult(
        ActivityResultContracts.OpenMultipleDocuments()
    ) { uris ->
        if (uris.isNotEmpty()) {
            uris.forEach { uri ->
                runCatching {
                    contentResolver.takePersistableUriPermission(
                        uri, android.content.Intent.FLAG_GRANT_READ_URI_PERMISSION
                    )
                }
                if (!playlist.contains(uri)) playlist.add(uri)
            }
            persistPlaylist()
            currentIndex = playlist.indexOf(uris.first())
            playUri(uris.first())
            status.text = "Imported ${uris.size} item(s) • Playlist ${playlist.size}"
            showStudio()
        }
    }

    private val logoPicker = registerForActivityResult(
        ActivityResultContracts.OpenDocument()
    ) { uri ->
        if (uri != null) {
            runCatching {
                contentResolver.takePersistableUriPermission(
                    uri, android.content.Intent.FLAG_GRANT_READ_URI_PERMISSION
                )
            }
            logoUri = uri
            logoOverlay = ImageView(this).apply {
                setImageURI(uri)
                scaleType = ImageView.ScaleType.FIT_CENTER
                contentDescription = "Logo overlay"
            }
            currentPreview?.let { restoreOverlays(it) }
        }
    }

    private val permissionRequest = registerForActivityResult(
        ActivityResultContracts.RequestMultiplePermissions()
    ) { grants ->
        if (grants[Manifest.permission.CAMERA] == true) startCamera()
        else status.text = "Camera permission is required for camera preview/recording"
    }

    private val webPicker = registerForActivityResult(
        ActivityResultContracts.StartActivityForResult()
    ) { result ->
        val callback = pendingWebCallback
        pendingWebCallback = null
        if (result.resultCode == RESULT_OK) {
            val found = mutableListOf<Uri>()
            result.data?.data?.let { found.add(it) }
            result.data?.clipData?.let { clip ->
                for (i in 0 until clip.itemCount) found.add(clip.getItemAt(i).uri)
            }
            callback?.onReceiveValue(found.distinct().toTypedArray())
        } else callback?.onReceiveValue(null)
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        prefs = getSharedPreferences("media_bridge_v4", Context.MODE_PRIVATE)
        restorePlaylist()
        buildBaseUi()
        showStudio()
    }

    private fun buildBaseUi() {
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setBackgroundColor(0xFF101216.toInt())
        }
        val header = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(18), dp(14), dp(18), dp(12))
            setBackgroundColor(0xFF171B22.toInt())
        }
        header.addView(TextView(this).apply {
            text = "MEDIABRIDGE STUDIO  V6"
            textSize = 19f
            typeface = android.graphics.Typeface.DEFAULT_BOLD
            setTextColor(0xFFFFFFFF.toInt())
        })
        header.addView(TextView(this).apply {
            text = "MEDIA PRODUCTION  •  RECORDING  •  STREAM SETUP"
            textSize = 9f
            letterSpacing = .12f
            setTextColor(0xFF9AA8BA.toInt())
        })
        root.addView(header)

        val nav = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            setPadding(dp(7), dp(7), dp(7), dp(7))
            setBackgroundColor(0xFF202630.toInt())
        }
        nav.addView(navButton("STUDIO") { showStudio() }, weightParams())
        nav.addView(navButton("SOURCES") { showSources() }, weightParams())
        nav.addView(navButton("LIBRARY") { showLibrary() }, weightParams())
        nav.addView(navButton("BROWSER") { showBrowser() }, weightParams())
        nav.addView(navButton("RTMP") { showRtmpSettings() }, weightParams())
        root.addView(nav)

        stage = FrameLayout(this).apply { setPadding(dp(12), dp(12), dp(12), dp(12)) }
        root.addView(stage, LinearLayout.LayoutParams(-1, 0, 1f))

        status = TextView(this).apply {
            text = "Ready"
            textSize = 11f
            setTextColor(0xFFD0D8E2.toInt())
            setPadding(dp(14), dp(9), dp(14), dp(9))
            setBackgroundColor(0xFF171B22.toInt())
        }
        root.addView(status)
        setContentView(root)
    }

    private fun showStudio() {
        closeBrowser()
        stage.removeAllViews()
        val col = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        val preview = FrameLayout(this).apply { setBackgroundColor(0xFF050608.toInt()) }
        preview.addView(TextView(this).apply {
            text = "STUDIO PREVIEW"
            gravity = Gravity.CENTER
            textSize = 12f
            setTextColor(0xFF8F9BAB.toInt())
        }, FrameLayout.LayoutParams(-1, -1))
        currentPreview = preview
        col.addView(preview, LinearLayout.LayoutParams(-1, 0, 1f))

        val row1 = horizontal()
        row1.addView(actionButton("CAMERA") { ensureCameraPermission() }, weightParams())
        row1.addView(actionButton("ADD MEDIA") { mediaPicker.launch(arrayOf("image/*", "video/*")) }, weightParams())
        row1.addView(actionButton("RECORD") { startRecording() }, weightParams())
        row1.addView(actionButton("STOP REC") { stopRecording() }, weightParams())
        col.addView(row1)

        val row2 = horizontal()
        row2.addView(actionButton("PLAY") { playCurrent() }, weightParams())
        row2.addView(actionButton("PAUSE") { player?.pause(); status.text = "Playback paused" }, weightParams())
        row2.addView(actionButton("NEXT") { playNext() }, weightParams())
        row2.addView(actionButton("STOP") { stopPlaybackAndCamera() }, weightParams())
        col.addView(row2)

        val row3 = horizontal()
        row3.addView(actionButton(if (repeatOne) "LOOP ON" else "LOOP OFF") {
            repeatOne = !repeatOne
            status.text = "Repeat-one ${if (repeatOne) "enabled" else "disabled"}"
            showStudio()
        }, weightParams())
        row3.addView(actionButton(if (shuffleNext) "SHUFFLE ON" else "SHUFFLE OFF") {
            shuffleNext = !shuffleNext
            status.text = "Shuffle-next ${if (shuffleNext) "enabled" else "disabled"}"
            showStudio()
        }, weightParams())
        row3.addView(actionButton("TEXT") { promptTextOverlay() }, weightParams())
        row3.addView(actionButton("LOGO") { logoPicker.launch(arrayOf("image/*")) }, weightParams())
        col.addView(row3)

        val sourceRow = horizontal()
        sourceRow.addView(actionButton("SOURCE MANAGER") { showSources() }, weightParams())
        sourceRow.addView(actionButton("SWITCH TO CAMERA") { ensureCameraPermission() }, weightParams())
        sourceRow.addView(actionButton("SWITCH TO MEDIA") { playCurrent() }, weightParams())
        col.addView(sourceRow)

        val playlistText = TextView(this).apply {
            textSize = 10f
            setTextColor(0xFFD5DCE6.toInt())
            setPadding(dp(9), dp(8), dp(9), dp(8))
            setBackgroundColor(0xFF202630.toInt())
            text = playlistSummary()
        }
        col.addView(playlistText)
        stage.addView(col)
        if (currentIndex in playlist.indices) playUri(playlist[currentIndex])
        else restoreOverlays(preview)
    }

    private fun showSources() {
        closeBrowser()
        stage.removeAllViews()
        val col = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        col.addView(TextView(this).apply {
            text = "SOURCE MANAGER"
            textSize = 18f
            typeface = android.graphics.Typeface.DEFAULT_BOLD
            setTextColor(0xFFFFFFFF.toInt())
        })
        col.addView(TextView(this).apply {
            text = "Select one input as the main studio preview."
            textSize = 11f
            setTextColor(0xFF9AA8BA.toInt())
            setPadding(0, dp(4), 0, dp(10))
        })
        col.addView(actionButton("PHONE CAMERA • PRIMARY") {
            showStudio()
            ensureCameraPermission()
        })
        col.addView(actionButton("IMPORT IMAGE / VIDEO SOURCE") {
            mediaPicker.launch(arrayOf("image/*", "video/*"))
        })
        col.addView(actionButton("PLAY SELECTED SOURCE") {
            val uri = playlist.getOrNull(currentIndex)
            if (uri == null) status.text = "Import a media source first"
            else {
                showStudio()
                playUri(uri)
            }
        })
        col.addView(actionButton("OPEN SOURCE PLAYLIST") { showLibrary() })
        col.addView(TextView(this).apply {
            text = "AVAILABLE SOURCES"
            textSize = 12f
            typeface = android.graphics.Typeface.DEFAULT_BOLD
            setTextColor(0xFFB8C7D9.toInt())
            setPadding(0, dp(16), 0, dp(6))
        })
        col.addView(TextView(this).apply {
            text = "1. Device Camera\\n" + playlist.mapIndexed { index, uri ->
                "${index + 2}. ${uri.lastPathSegment ?: "Media source"}"
            }.joinToString("\\n")
            textSize = 12f
            setTextColor(0xFFD5DCE6.toInt())
            setPadding(dp(10), dp(10), dp(10), dp(10))
            setBackgroundColor(0xFF202630.toInt())
        })
        col.addView(TextView(this).apply {
            text = "V5 currently switches the primary preview between sources. Simultaneous multi-input compositing, chroma key and RTMP publishing need a dedicated rendering and streaming engine and are not active in this build."
            textSize = 11f
            setTextColor(0xFFFFC66D.toInt())
            setPadding(0, dp(12), 0, dp(8))
        })
        stage.addView(ScrollView(this).apply { addView(col) })
        status.text = "Source manager • ${playlist.size + 1} available source(s)"
    }

    private fun showLibrary() {
        closeBrowser()
        stage.removeAllViews()
        val col = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        col.addView(TextView(this).apply {
            text = "MEDIA LIBRARY"
            textSize = 18f
            setTextColor(0xFFFFFFFF.toInt())
        })
        col.addView(actionButton("IMPORT PHOTOS / VIDEOS") {
            mediaPicker.launch(arrayOf("image/*", "video/*"))
        })
        playlist.forEachIndexed { index, uri ->
            val item = LinearLayout(this).apply {
                orientation = LinearLayout.HORIZONTAL
                setPadding(0, dp(5), 0, dp(5))
            }
            val label = TextView(this).apply {
                text = "${index + 1}. ${uri.lastPathSegment ?: "Media"}"
                setTextColor(0xFFE0E5EC.toInt())
                textSize = 12f
            }
            item.addView(label, LinearLayout.LayoutParams(0, dp(44), 1f))
            item.addView(actionButton("PLAY") {
                currentIndex = index
                playUri(uri)
                showStudio()
            })
            item.addView(actionButton("REMOVE") {
                playlist.remove(uri)
                if (currentIndex >= playlist.size) currentIndex = playlist.lastIndex
                persistPlaylist()
                showLibrary()
            })
            col.addView(item)
        }
        stage.addView(ScrollView(this).apply { addView(col) })
        status.text = "${playlist.size} saved playlist item(s)"
    }

    private fun showBrowser() {
        cameraProvider?.unbindAll()
        stopPlayer()
        stage.removeAllViews()
        val col = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        val row = horizontal()
        val url = EditText(this).apply {
            setText("https://")
            hint = "Website address"
            setSingleLine(true)
            setTextColor(0xFFFFFFFF.toInt())
            setHintTextColor(0xFF9AA8BA.toInt())
            setBackgroundColor(0xFF252C37.toInt())
        }
        address = url
        row.addView(url, LinearLayout.LayoutParams(0, dp(46), 1f))
        row.addView(actionButton("GO") { loadWebsite() })
        col.addView(row)

        val web = WebView(this).apply {
            settings.javaScriptEnabled = true
            settings.domStorageEnabled = true
            settings.allowFileAccess = false
            settings.allowContentAccess = true
            webViewClient = object : WebViewClient() {
                override fun shouldOverrideUrlLoading(view: WebView?, request: WebResourceRequest?) = false
            }
            webChromeClient = object : WebChromeClient() {
                override fun onShowFileChooser(
                    webView: WebView?,
                    filePathCallback: ValueCallback<Array<Uri>>?,
                    fileChooserParams: FileChooserParams?
                ): Boolean {
                    pendingWebCallback?.onReceiveValue(null)
                    pendingWebCallback = filePathCallback
                    val intent = fileChooserParams?.createIntent()
                        ?: android.content.Intent(android.content.Intent.ACTION_OPEN_DOCUMENT).apply {
                            addCategory(android.content.Intent.CATEGORY_OPENABLE)
                            type = "*/*"
                            putExtra(android.content.Intent.EXTRA_MIME_TYPES, arrayOf("image/*", "video/*"))
                        }
                    return try {
                        webPicker.launch(intent)
                        true
                    } catch (_: Exception) {
                        pendingWebCallback = null
                        filePathCallback?.onReceiveValue(null)
                        false
                    }
                }
            }
        }
        browser = web
        col.addView(web, LinearLayout.LayoutParams(-1, 0, 1f))
        stage.addView(col)
        status.text = "Browser • standard website file upload supported"
    }

    private fun loadWebsite() {
        var url = address.text.toString().trim()
        if (url.isBlank()) return
        if (!url.startsWith("https://") && !url.startsWith("http://")) url = "https://$url"
        address.setText(url)
        browser?.loadUrl(url)
    }

    private fun showRtmpSettings() {
        closeBrowser()
        stage.removeAllViews()
        val col = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        col.addView(TextView(this).apply {
            text = "RTMP OUTPUT SETTINGS"
            textSize = 18f
            setTextColor(0xFFFFFFFF.toInt())
        })
        val server = EditText(this).apply {
            hint = "rtmp://server/live"
            setTextColor(0xFFFFFFFF.toInt())
            setText(prefs.getString("rtmp_server", "") ?: "")
        }
        val key = EditText(this).apply {
            hint = "Stream key"
            inputType = android.text.InputType.TYPE_CLASS_TEXT or
                android.text.InputType.TYPE_TEXT_VARIATION_PASSWORD
            setTextColor(0xFFFFFFFF.toInt())
            setText(prefs.getString("rtmp_key", "") ?: "")
        }
        col.addView(server)
        col.addView(key)
        col.addView(actionButton("SAVE SETTINGS") {
            prefs.edit().putString("rtmp_server", server.text.toString().trim())
                .putString("rtmp_key", key.text.toString()).apply()
            status.text = "RTMP settings saved on this device"
        })
        col.addView(actionButton("OPEN LIVE BROADCAST") {
            val fullUrl = server.text.toString().trim().trimEnd('/') + "/" + key.text.toString().trim()
            prefs.edit().putString("rtmp_server", server.text.toString().trim())
                .putString("rtmp_key", key.text.toString()).apply()
            startActivity(android.content.Intent(this, LiveBroadcastActivity::class.java).putExtra("rtmp_url", fullUrl))
        })
        col.addView(TextView(this).apply {
            text = "V6: Live RTMP uses a dedicated RootEncoder broadcast screen. Enter the full publishing URL in the broadcast screen if your server uses a different format."
            textSize = 12f
            setTextColor(0xFFFFC66D.toInt())
            setPadding(0, dp(12), 0, dp(12))
        })
        stage.addView(col)
    }

    private fun ensureCameraPermission() {
        val missing = mutableListOf<String>()
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.CAMERA) != PackageManager.PERMISSION_GRANTED)
            missing.add(Manifest.permission.CAMERA)
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED)
            missing.add(Manifest.permission.RECORD_AUDIO)
        if (missing.isEmpty()) startCamera() else permissionRequest.launch(missing.toTypedArray())
    }

    private fun startCamera() {
        stopPlayer()
        val future = ProcessCameraProvider.getInstance(this)
        future.addListener({
            try {
                val provider = future.get()
                cameraProvider = provider
                val frame = currentPreview ?: return@addListener
                frame.removeAllViews()
                val pv = PreviewView(this).apply { scaleType = PreviewView.ScaleType.FILL_CENTER }
                frame.addView(pv, FrameLayout.LayoutParams(-1, -1))
                val preview = Preview.Builder().build().also { it.setSurfaceProvider(pv.surfaceProvider) }
                val recorder = Recorder.Builder()
                    .setQualitySelector(QualitySelector.from(Quality.HD))
                    .build()
                videoCapture = VideoCapture.withOutput(recorder)
                provider.unbindAll()
                provider.bindToLifecycle(
                    this, CameraSelector.DEFAULT_BACK_CAMERA, preview, videoCapture
                )
                restoreOverlays(frame)
                status.text = "Camera ready • HD preview"
            } catch (e: Exception) {
                status.text = "Camera error: ${e.localizedMessage ?: "unknown"}"
            }
        }, ContextCompat.getMainExecutor(this))
    }

    private fun startRecording() {
        if (videoCapture == null) {
            status.text = "Start Camera first"
            ensureCameraPermission()
            return
        }
        if (activeRecording != null) {
            status.text = "Recording is already active"
            return
        }
        val folder = getExternalFilesDir(android.os.Environment.DIRECTORY_MOVIES)
            ?: filesDir
        if (!folder.exists()) folder.mkdirs()
        val stamp = SimpleDateFormat("yyyyMMdd_HHmmss", Locale.US).format(Date())
        val file = File(folder, "MediaBridge_$stamp.mp4")
        val output = FileOutputOptions.Builder(file).build()
        var pending = videoCapture!!.output.prepareRecording(this, output)
        val audioAllowed = ContextCompat.checkSelfPermission(
            this, Manifest.permission.RECORD_AUDIO
        ) == PackageManager.PERMISSION_GRANTED
        if (audioAllowed) pending = pending.withAudioEnabled()

        activeRecording = pending.start(ContextCompat.getMainExecutor(this)) { event ->
            when (event) {
                is VideoRecordEvent.Start -> status.text = "● Recording started"
                is VideoRecordEvent.Finalize -> {
                    activeRecording = null
                    if (event.hasError()) {
                        status.text = "Recording failed: ${event.error}"
                    } else {
                        status.text = "Recording saved: ${file.name}"
                        Toast.makeText(this, "Saved in app Movies folder", Toast.LENGTH_LONG).show()
                    }
                }
            }
        }
    }

    private fun stopRecording() {
        val recording = activeRecording
        if (recording == null) {
            status.text = "No active recording"
            return
        }
        recording.stop()
        status.text = "Saving recording…"
    }

    private fun playCurrent() {
        val uri = playlist.getOrNull(currentIndex)
        if (uri == null) status.text = "Import media first" else playUri(uri)
    }

    private fun playNext() {
        if (playlist.isEmpty()) {
            status.text = "Playlist is empty"
            return
        }
        currentIndex = if (shuffleNext && playlist.size > 1)
            (playlist.indices.filter { it != currentIndex }).random()
        else currentIndex + 1
        if (currentIndex >= playlist.size) {
            if (repeatOne) currentIndex = 0
            else {
                currentIndex = playlist.lastIndex
                status.text = "Playlist finished"
                return
            }
        }
        persistPlaylist()
        playUri(playlist[currentIndex])
    }

    private fun playUri(uri: Uri) {
        currentIndex = playlist.indexOf(uri).takeIf { it >= 0 } ?: currentIndex
        stopPlayer()
        cameraProvider?.unbindAll()
        val frame = currentPreview
        if (frame == null) return
        frame.removeAllViews()
        val mime = contentResolver.getType(uri).orEmpty()
        if (mime.startsWith("video/")) {
            val pv = PlayerView(this).apply { useController = true }
            frame.addView(pv, FrameLayout.LayoutParams(-1, -1))
            player = ExoPlayer.Builder(this).build().also { exo ->
                pv.player = exo
                exo.setMediaItem(MediaItem.fromUri(uri))
                exo.repeatMode = if (repeatOne) ExoPlayer.REPEAT_MODE_ONE else ExoPlayer.REPEAT_MODE_OFF
                exo.prepare()
                exo.playWhenReady = true
            }
            status.text = "Playing video"
        } else {
            frame.addView(ImageView(this).apply {
                setImageURI(uri)
                scaleType = ImageView.ScaleType.FIT_CENTER
            }, FrameLayout.LayoutParams(-1, -1))
            status.text = "Image preview"
        }
        restoreOverlays(frame)
    }

    private fun promptTextOverlay() {
        val input = EditText(this).apply {
            hint = "Text to display"
            setText(textOverlay?.text ?: "MediaBridge Studio")
        }
        android.app.AlertDialog.Builder(this)
            .setTitle("Text Overlay")
            .setView(input)
            .setNegativeButton("Cancel", null)
            .setPositiveButton("Apply") { _, _ ->
                val value = input.text.toString().trim()
                if (value.isNotEmpty()) {
                    textOverlay = TextView(this).apply {
                        text = value
                        textSize = 20f
                        setTextColor(0xFFFFFFFF.toInt())
                        setShadowLayer(5f, 2f, 2f, 0xFF000000.toInt())
                        setBackgroundColor(0x66000000)
                        setPadding(dp(8), dp(5), dp(8), dp(5))
                    }
                    currentPreview?.let { restoreOverlays(it) }
                }
            }.show()
    }

    private fun restoreOverlays(frame: FrameLayout) {
        textOverlay?.let { view ->
            if (view.parent == null) frame.addView(
                view, FrameLayout.LayoutParams(-2, -2, Gravity.TOP or Gravity.CENTER_HORIZONTAL)
                    .apply { topMargin = dp(12) }
            )
        }
        logoOverlay?.let { view ->
            if (view.parent == null) frame.addView(
                view, FrameLayout.LayoutParams(dp(86), dp(62), Gravity.BOTTOM or Gravity.END)
                    .apply { rightMargin = dp(12); bottomMargin = dp(12) }
            )
        }
    }

    private fun persistPlaylist() {
        prefs.edit().putString("playlist", playlist.joinToString("\n") { it.toString() })
            .putInt("current_index", currentIndex).apply()
    }

    private fun restorePlaylist() {
        val saved = prefs.getString("playlist", "") ?: ""
        saved.lineSequence().filter { it.isNotBlank() }.forEach { line ->
            runCatching { playlist.add(Uri.parse(line)) }
        }
        currentIndex = prefs.getInt("current_index", -1).coerceIn(-1, playlist.lastIndex)
    }

    private fun playlistSummary(): String {
        if (playlist.isEmpty()) return "PLAYLIST • Empty — Import photos or videos"
        return "PLAYLIST • ${playlist.size} saved item(s)\n" +
            playlist.mapIndexed { i, uri ->
                "${if (i == currentIndex) "▶" else " "} ${i + 1}. ${uri.lastPathSegment ?: "Media"}"
            }.joinToString("\n")
    }

    private fun stopPlaybackAndCamera() {
        stopPlayer()
        cameraProvider?.unbindAll()
        currentPreview?.removeAllViews()
        status.text = "Preview stopped"
    }

    private fun stopPlayer() {
        player?.release()
        player = null
    }

    private fun closeBrowser() {
        browser?.stopLoading()
        browser?.destroy()
        browser = null
    }

    private fun horizontal() = LinearLayout(this).apply {
        orientation = LinearLayout.HORIZONTAL
    }

    private fun navButton(label: String, click: () -> Unit) = Button(this).apply {
        text = label
        textSize = 9f
        setTextColor(0xFFFFFFFF.toInt())
        setBackgroundTintList(android.content.res.ColorStateList.valueOf(0xFF303A49.toInt()))
        setOnClickListener { click() }
    }

    private fun actionButton(label: String, click: () -> Unit) = Button(this).apply {
        text = label
        textSize = 9f
        setTextColor(0xFFFFFFFF.toInt())
        setBackgroundTintList(android.content.res.ColorStateList.valueOf(0xFF45566E.toInt()))
        setOnClickListener { click() }
    }

    private fun weightParams() = LinearLayout.LayoutParams(0, dp(42), 1f)
    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()

    override fun onDestroy() {
        pendingWebCallback?.onReceiveValue(null)
        pendingWebCallback = null
        activeRecording?.stop()
        closeBrowser()
        stopPlayer()
        cameraProvider?.unbindAll()
        super.onDestroy()
    }
}
