package com.example.mediabridgestudio

import android.Manifest
import android.content.pm.PackageManager
import android.os.Bundle
import android.view.Gravity
import android.view.SurfaceHolder
import android.view.SurfaceView
import android.widget.Button
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.TextView
import androidx.activity.ComponentActivity
import androidx.activity.result.contract.ActivityResultContracts
import androidx.core.content.ContextCompat
import com.pedro.common.ConnectChecker
import com.pedro.common.StreamingStatsReport
import com.pedro.common.Throughput
import com.pedro.common.onMainThreadHandler
import com.pedro.library.generic.GenericStream
import java.util.Locale

/** Dedicated RootEncoder RTMP broadcast screen. Requires a valid RTMP(S) URL and camera/mic permissions. */
class LiveBroadcastActivity : ComponentActivity(), ConnectChecker {
    private lateinit var stream: GenericStream
    private lateinit var surface: SurfaceView
    private lateinit var urlInput: EditText
    private lateinit var status: TextView
    private lateinit var startButton: Button
    private var prepared = false
    private var surfaceReady = false

    private val permissions = registerForActivityResult(
        ActivityResultContracts.RequestMultiplePermissions()
    ) { grants ->
        val cameraOk = grants[Manifest.permission.CAMERA] == true ||
            ContextCompat.checkSelfPermission(this, Manifest.permission.CAMERA) == PackageManager.PERMISSION_GRANTED
        val audioOk = grants[Manifest.permission.RECORD_AUDIO] == true ||
            ContextCompat.checkSelfPermission(this, Manifest.permission.RECORD_AUDIO) == PackageManager.PERMISSION_GRANTED
        if (cameraOk && audioOk) prepareStream() else status.text = "Camera and microphone permissions are required."
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        stream = GenericStream(applicationContext, this)
        buildUi()
        urlInput.setText(intent.getStringExtra("rtmp_url") ?: "")
        surface.holder.addCallback(object : SurfaceHolder.Callback {
            override fun surfaceCreated(holder: SurfaceHolder) {
                surfaceReady = true
                if (prepared && !stream.isOnPreview) stream.startPreview(surface)
            }
            override fun surfaceChanged(holder: SurfaceHolder, format: Int, width: Int, height: Int) {
                if (width > 0 && height > 0) stream.getGlInterface().setPreviewResolution(width, height)
            }
            override fun surfaceDestroyed(holder: SurfaceHolder) {
                surfaceReady = false
                if (stream.isOnPreview) stream.stopPreview()
            }
        })
        requestPermissionsIfNeeded()
    }

    private fun buildUi() {
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(16, 16, 16, 16)
            setBackgroundColor(0xFF101216.toInt())
        }
        root.addView(TextView(this).apply {
            text = "LIVE BROADCAST • RTMP"
            textSize = 19f
            setTextColor(0xFFFFFFFF.toInt())
            setPadding(0, 0, 0, 10)
        })
        root.addView(TextView(this).apply {
            text = "Camera + microphone encoder powered by RootEncoder"
            textSize = 11f
            setTextColor(0xFF9AA8BA.toInt())
        })
        surface = SurfaceView(this)
        root.addView(surface, LinearLayout.LayoutParams(-1, 0, 1f).apply { topMargin = 12; bottomMargin = 12 })
        urlInput = EditText(this).apply {
            hint = "rtmp://server/app/stream-key"
            setSingleLine(true)
            setTextColor(0xFFFFFFFF.toInt())
            setHintTextColor(0xFF9AA8BA.toInt())
            setBackgroundColor(0xFF252C37.toInt())
            setPadding(12, 8, 12, 8)
        }
        root.addView(urlInput, LinearLayout.LayoutParams(-1, -2))
        startButton = Button(this).apply {
            text = "START LIVE"
            setOnClickListener { toggleStreaming() }
        }
        root.addView(startButton)
        status = TextView(this).apply {
            text = "Waiting for permissions…"
            textSize = 12f
            setTextColor(0xFFD0D8E2.toInt())
            gravity = Gravity.CENTER_VERTICAL
            setPadding(0, 12, 0, 8)
        }
        root.addView(status)
        root.addView(Button(this).apply {
            text = "CLOSE"
            setOnClickListener { finish() }
        })
        setContentView(root)
    }

    private fun requestPermissionsIfNeeded() {
        val missing = arrayOf(Manifest.permission.CAMERA, Manifest.permission.RECORD_AUDIO)
            .filter { ContextCompat.checkSelfPermission(this, it) != PackageManager.PERMISSION_GRANTED }
        if (missing.isEmpty()) prepareStream() else permissions.launch(missing.toTypedArray())
    }

    private fun prepareStream() {
        if (prepared) return
        val ok = runCatching {
            stream.prepareVideo(1280, 720, 2_000_000) &&
                stream.prepareAudio(44_100, true, 128_000)
        }.getOrDefault(false)
        if (!ok) {
            status.text = "Encoder setup failed on this device. Try a lower resolution."
            return
        }
        prepared = true
        if (surfaceReady && !stream.isOnPreview) stream.startPreview(surface)
        status.text = "Preview ready • enter your RTMP URL to go live"
    }

    private fun toggleStreaming() {
        if (!prepared) {
            status.text = "Encoder is not ready yet."
            return
        }
        if (stream.isStreaming) {
            stream.stopStream()
            startButton.text = "START LIVE"
            status.text = "Stopping stream…"
            return
        }
        val target = urlInput.text.toString().trim()
        if (!(target.startsWith("rtmp://") || target.startsWith("rtmps://"))) {
            status.text = "Enter a valid rtmp:// or rtmps:// publishing URL."
            return
        }
        stream.startStream(target)
        startButton.text = "STOP LIVE"
        status.text = "Connecting…"
    }

    override fun onConnectionStarted(url: String) { onMainThreadHandler { status.text = "Connecting to streaming server…" } }
    override fun onConnectionSuccess() { onMainThreadHandler { status.text = "● LIVE • Connected to server" } }
    override fun onConnectionFailed(reason: String) {
        onMainThreadHandler {
            status.text = "Connection failed: $reason"
            startButton.text = "START LIVE"
            if (stream.isStreaming) stream.stopStream()
        }
    }
    override fun onDisconnect() { onMainThreadHandler { status.text = "Disconnected"; startButton.text = "START LIVE" } }
    override fun onAuthError() { onMainThreadHandler { status.text = "Authentication failed • check stream key"; startButton.text = "START LIVE" } }
    override fun onAuthSuccess() { onMainThreadHandler { status.text = "Stream key accepted" } }
    override fun onStreamingStats(report: StreamingStatsReport) {
        onMainThreadHandler {
            if (report.throughput != Throughput.UNKNOWN) {
                status.text = String.format(Locale.US, "● LIVE • %.2f Mbps", report.smoothedBitrate / 1_000_000f)
            }
        }
    }

    override fun onDestroy() {
        if (stream.isStreaming) stream.stopStream()
        stream.release()
        super.onDestroy()
    }
}
